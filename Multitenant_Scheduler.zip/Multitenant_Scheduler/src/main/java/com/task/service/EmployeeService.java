package com.task.service;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.datetime.joda.MillisecondInstantPrinter;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.task.bean.Employee;
import com.task.repo.EmployeeRepository;




@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	  public void save(Employee employee) {
		  employeeRepository.save(employee);
	    }
	  
	  public List<Employee> getAll() throws SQLException {
		    return employeeRepository.findAll();

	    }

	    public Employee get(Long id) {
	        return employeeRepository.findById(id).get();
	    }

	    public Employee getByName(String name) {
	        return employeeRepository.findByName(name);
	    }

	    public void delete(String name) {
	    	employeeRepository.deleteByName(name);
	    }
	    Logger log=LoggerFactory.getLogger(EmployeeService.class);
	 // schedule a job to add object in DB (Every 5 sec)
/*
		@Scheduled(fixedRate = 5000)
		public void add2DBJob() {
			 Employee  employee  = new Employee ();
			 employee.setName("employee" + new Random().nextInt(374483));
			 employeeRepository.save(employee);
		//	System.out.println("add service call in " + new Date().toString());

		}
		@Scheduled(cron = "0/15 * * * * ")
		public void fetchDBJob() {
			List<Employee> employees  =employeeRepository.findAll();
			//System.out.println("fetch service call in " + new Date().toString());
			//System.out.println("no of record fetchid : "+employees.size()); 
			log.info("employees : {}",employees);
		}
		*/
	    @Scheduled(fixedRate = 1000)
	    public void scheduler() throws InterruptedException{
	    	LocalDateTime current = LocalDateTime.now();
	    	DateTimeFormatter format = DateTimeFormatter.ofPattern("dd=MM-yyy HH:mm:ss");
	    	String formattedDateTime =current.format(format);
	    	log.info("Scheduler time "+ formattedDateTime);
	    	
	  
	    }  

}


